#pragma once

#include <Arduino.h>

/* ======================================================================
   FUNCTION PROTOTYPES
   ====================================================================== */

int readAveragedAnaloguePinReading(byte pin, int samples, int delayUs);
